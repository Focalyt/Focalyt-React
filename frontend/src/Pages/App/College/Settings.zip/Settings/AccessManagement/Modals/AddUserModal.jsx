import React, { useState } from 'react';

const AddUserModal = ({ 
  users, 
  allRoles, 
  entities, 
  onClose, 
  onAddUser 
}) => {
  const [userForm, setUserForm] = useState({
    name: '',
    email: '',
    role: '',
    permission_type: 'hierarchical',
    // Hierarchical fields
    entity_type: '',
    entity_id: '',
    multiple_entities: [],
    // Lead-based fields
    reporting_managers: [],
    centers_access: [],
    // Hybrid fields
    hierarchical_entity: '',
    lead_team: ''
  });

  const handleSubmit = () => {
    const newUser = {
      user_id: `user_${Date.now()}`,
      name: userForm.name,
      email: userForm.email,
      role: userForm.role,
      status: 'active',
      permission_type: userForm.permission_type,
      reporting_managers: userForm.reporting_managers,
      centers_access: userForm.centers_access,
      entity_name: userForm.entity_type ? getEntityName(userForm.entity_type, userForm.entity_id) : '',
      assigned_leads: [] // Will be assigned later
    };
    
    onAddUser(newUser);
  };

  const getEntityName = (type, id) => {
    if (!type || !id) return '';
    const entityList = entities[type];
    const entity = entityList?.find(e => e.id === id);
    return entity?.name || '';
  };

  return (
    <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1050 }}>
      <div className="modal-dialog modal-lg modal-dialog-scrollable">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Add New User</h5>
            <button
              type="button"
              className="btn-close"
              onClick={onClose}
            ></button>
          </div>
          <div className="modal-body">
            <div className="row g-3">
              {/* Basic Info */}
              <div className="col-12">
                <h6 className="fw-medium mb-3">Basic Information</h6>
              </div>
              <div className="col-md-6">
                <label className="form-label">Name *</label>
                <input
                  type="text"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  className="form-control"
                  placeholder="Enter user's full name"
                />
              </div>
              <div className="col-md-6">
                <label className="form-label">Email *</label>
                <input
                  type="email"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  className="form-control"
                  placeholder="user@company.com"
                />
              </div>

              {/* Permission Type Selection */}
              <div className="col-12">
                <h6 className="fw-medium mb-3 mt-4">Permission Type</h6>
                <div className="row g-2">
                  <div className="col-md-4">
                    <div className="form-check">
                      <input
                        type="radio"
                        name="permission_type"
                        value="hierarchical"
                        checked={userForm.permission_type === 'hierarchical'}
                        onChange={(e) => setUserForm({
                          ...userForm,
                          permission_type: e.target.value,
                          role: ''
                        })}
                        className="form-check-input"
                        id="perm_hierarchical"
                      />
                      <label className="form-check-label" htmlFor="perm_hierarchical">
                        <div className="fw-medium text-info">📋 Content Management</div>
                        <div className="small text-muted">Hierarchical content permissions</div>
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check">
                      <input
                        type="radio"
                        name="permission_type"
                        value="lead_based"
                        checked={userForm.permission_type === 'lead_based'}
                        onChange={(e) => setUserForm({
                          ...userForm,
                          permission_type: e.target.value,
                          role: ''
                        })}
                        className="form-check-input"
                        id="perm_lead_based"
                      />
                      <label className="form-check-label" htmlFor="perm_lead_based">
                        <div className="fw-medium text-success">🎯 Lead Management</div>
                        <div className="small text-muted">Team & lead-based access</div>
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check">
                      <input
                        type="radio"
                        name="permission_type"
                        value="hybrid"
                        checked={userForm.permission_type === 'hybrid'}
                        onChange={(e) => setUserForm({
                          ...userForm,
                          permission_type: e.target.value,
                          role: ''
                        })}
                        className="form-check-input"
                        id="perm_hybrid"
                      />
                      <label className="form-check-label" htmlFor="perm_hybrid">
                        <div className="fw-medium text-warning">⚡ Hybrid Access</div>
                        <div className="small text-muted">Both content & lead management</div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Role Selection */}
              <div className="col-12">
                <label className="form-label">Role *</label>
                <select
                  value={userForm.role}
                  onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
                  className="form-select"
                >
                  <option value="">Select Role</option>
                  {Object.entries(allRoles)
                    .filter(([key, role]) =>
                      userForm.permission_type === 'hybrid' ? role.type === 'hybrid' :
                        role.type === userForm.permission_type
                    )
                    .map(([roleKey, role]) => (
                      <option key={roleKey} value={roleKey}>{role.name}</option>
                    ))}
                </select>
              </div>

              {/* Hierarchical Fields */}
              {userForm.permission_type === 'hierarchical' && (
                <>
                  <div className="col-12">
                    <h6 className="fw-medium mb-3 mt-3">📋 Content Management Assignment</h6>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Entity Type</label>
                    <select
                      value={userForm.entity_type}
                      onChange={(e) => setUserForm({ ...userForm, entity_type: e.target.value, entity_id: '' })}
                      className="form-select"
                    >
                      <option value="">Select Entity Type</option>
                      <option value="VERTICAL">Vertical</option>
                      <option value="PROJECT">Project</option>
                      <option value="CENTER">Center</option>
                      <option value="COURSE">Course</option>
                      <option value="BATCH">Batch</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Entity</label>
                    <select
                      value={userForm.entity_id}
                      onChange={(e) => setUserForm({ ...userForm, entity_id: e.target.value })}
                      className="form-select"
                      disabled={!userForm.entity_type}
                    >
                      <option value="">Select Entity</option>
                      {userForm.entity_type && entities[userForm.entity_type]?.map(entity => (
                        <option key={entity.id} value={entity.id}>{entity.name}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              {/* Lead-based Fields */}
              {userForm.permission_type === 'lead_based' && (
                <>
                  <div className="col-12">
                    <h6 className="fw-medium mb-3 mt-3">🎯 Lead Management Assignment</h6>
                  </div>
                  <div className="col-12">
                    <label className="form-label">Reporting Managers</label>
                    <div className="border rounded p-3" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                      <div className="small text-muted mb-2">Select one or multiple reporting managers:</div>
                      {users
                        .filter(user => 
                          ['TL_COUNSELLOR', 'TL_SALES', 'SALES_MANAGER', 'CENTER_SALES_HEAD'].includes(user.role)
                        )
                        .map(manager => (
                          <div key={manager.user_id} className="form-check mb-2">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              checked={userForm.reporting_managers.includes(manager.user_id)}
                              onChange={(e) => {
                                const updated = e.target.checked
                                  ? [...userForm.reporting_managers, manager.user_id]
                                  : userForm.reporting_managers.filter(id => id !== manager.user_id);
                                setUserForm({ ...userForm, reporting_managers: updated });
                              }}
                              id={`manager_${manager.user_id}`}
                            />
                            <label className="form-check-label" htmlFor={`manager_${manager.user_id}`}>
                              <div className="fw-medium">{manager.name}</div>
                              <div className="small text-muted">{allRoles[manager.role]?.name}</div>
                            </label>
                          </div>
                        ))}
                    </div>
                    {userForm.reporting_managers.length > 0 && (
                      <div className="form-text text-success mt-2">
                        ✅ Selected {userForm.reporting_managers.length} reporting manager(s)
                      </div>
                    )}
                  </div>

                  <div className="col-12">
                    <label className="form-label">Center Access</label>
                    <div className="border rounded p-3" style={{ maxHeight: '150px', overflowY: 'auto' }}>
                      <div className="small text-muted mb-2">Select centers this user can access:</div>
                      <div className="row">
                        {entities.CENTER.map(center => (
                          <div key={center.id} className="col-6">
                            <div className="form-check">
                              <input
                                type="checkbox"
                                className="form-check-input"
                                checked={userForm.centers_access.includes(center.id)}
                                onChange={(e) => {
                                  const updated = e.target.checked
                                    ? [...userForm.centers_access, center.id]
                                    : userForm.centers_access.filter(id => id !== center.id);
                                  setUserForm({ ...userForm, centers_access: updated });
                                }}
                                id={`center_${center.id}`}
                              />
                              <label className="form-check-label small" htmlFor={`center_${center.id}`}>
                                {center.name}
                              </label>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Hybrid Fields */}
              {userForm.permission_type === 'hybrid' && (
                <>
                  <div className="col-12">
                    <h6 className="fw-medium mb-3 mt-3">📋 Content Management Assignment</h6>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Entity Type</label>
                    <select
                      value={userForm.entity_type}
                      onChange={(e) => setUserForm({ ...userForm, entity_type: e.target.value })}
                      className="form-select"
                    >
                      <option value="">Select Entity Type</option>
                      <option value="CENTER">Center</option>
                      <option value="PROJECT">Project</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Entity</label>
                    <select
                      value={userForm.hierarchical_entity}
                      onChange={(e) => setUserForm({ ...userForm, hierarchical_entity: e.target.value })}
                      className="form-select"
                    >
                      <option value="">Select Entity</option>
                      {userForm.entity_type && entities[userForm.entity_type]?.map(entity => (
                        <option key={entity.id} value={entity.id}>{entity.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="col-12">
                    <h6 className="fw-medium mb-3 mt-3">🎯 Lead Management Assignment</h6>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Lead Team</label>
                    <select
                      value={userForm.lead_team}
                      onChange={(e) => setUserForm({ ...userForm, lead_team: e.target.value })}
                      className="form-select"
                    >
                      <option value="">Select Lead Team</option>
                      <option value="team_1">Sales Team A</option>
                      <option value="team_2">Counselling Team B</option>
                    </select>
                  </div>
                </>
              )}

              {/* Role Description */}
              {userForm.role && (
                <div className="col-12">
                  <div className="alert alert-light">
                    <h6 className="alert-heading">Role: {allRoles[userForm.role]?.name}</h6>
                    <div className="small">
                      {userForm.permission_type === 'hierarchical' && '📋 Hierarchical content management permissions'}
                      {userForm.permission_type === 'lead_based' && '🎯 Team-based lead management permissions'}
                      {userForm.permission_type === 'hybrid' && '⚡ Combined content management + lead management permissions'}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onClose}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={!userForm.name || !userForm.email || !userForm.role}
              className="btn btn-success"
            >
              Add User
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddUserModal;