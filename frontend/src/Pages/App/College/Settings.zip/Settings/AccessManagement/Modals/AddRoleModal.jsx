import React, { useState } from 'react';

const AddRoleModal = ({ 
  entities, 
  onClose, 
  onAddRole 
}) => {
  const [roleForm, setRoleForm] = useState({
    name: '',
    description: '',
    permission_type: 'hierarchical',
    view_access_type: 'SPECIFIC',
    master_level: '',
    specific_entities: [],

    // View Permissions
    view_permissions: {
      global: false,
      hierarchical_selection: {
        selected_verticals: [],
        selected_projects: [],
        selected_centers: [],
        selected_courses: [],
        selected_batches: []
      }
    },

    add_permissions: {
      global: false,
      specific_permissions: []
    },
    edit_permissions: {
      global: false,
      specific_permissions: []
    },
    verify_permissions: {
      global: false,
      type: '',
      vertical_types: [],
      specific_entities: [],
      parent_entities: [],
      selected_levels: []
    },

    // Lead-based Permissions
    lead_permissions: {
      view_own_leads: false,
      add_leads: false,
      edit_leads: false,
      view_team_leads: false,
      manage_assignments: false
    }
  });

  // Helper functions
  const getAvailableProjects = (selectedVerticals) => {
    if (!selectedVerticals || selectedVerticals.length === 0) return [];
    return entities.PROJECT.filter(project =>
      selectedVerticals.includes(project.parent_id)
    );
  };

  const getAvailableCenters = (selectedProjects) => {
    if (!selectedProjects || selectedProjects.length === 0) return [];
    return entities.CENTER.filter(center =>
      selectedProjects.includes(center.parent_id)
    );
  };

  const updateHierarchicalSelection = (level, selectedIds) => {
    const newSelection = { ...roleForm.view_permissions.hierarchical_selection };

    if (level === 'verticals') {
      newSelection.selected_verticals = selectedIds;
      newSelection.selected_projects = [];
      newSelection.selected_centers = [];
      newSelection.selected_courses = [];
      newSelection.selected_batches = [];
    } else if (level === 'projects') {
      newSelection.selected_projects = selectedIds;
      newSelection.selected_centers = [];
      newSelection.selected_courses = [];
      newSelection.selected_batches = [];
    } else if (level === 'centers') {
      newSelection.selected_centers = selectedIds;
      newSelection.selected_courses = [];
      newSelection.selected_batches = [];
    }

    setRoleForm({
      ...roleForm,
      view_permissions: {
        ...roleForm.view_permissions,
        hierarchical_selection: newSelection
      }
    });
  };

  const handleSubmit = () => {
    const newRole = {
      name: roleForm.name.toUpperCase().replace(/ /g, '_'),
      description: roleForm.description,
      permission_type: roleForm.permission_type,
      view_access: {
        type: roleForm.view_access_type,
        master_level: roleForm.master_level,
        specific_entities: roleForm.specific_entities
      },
      view_permissions: roleForm.view_permissions,
      add_permissions: roleForm.add_permissions,
      edit_permissions: roleForm.edit_permissions,
      verify_permissions: roleForm.verify_permissions,
      lead_permissions: roleForm.lead_permissions
    };

    console.log('New Role Created:', newRole);
    onAddRole(newRole);
  };

  return (
    <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1050 }}>
      <div className="modal-dialog modal-xl modal-dialog-scrollable">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Create New Role</h5>
            <button
              type="button"
              className="btn-close"
              onClick={onClose}
            ></button>
          </div>
          <div className="modal-body">
            <div className="row g-4">
              {/* Basic Information */}
              <div className="col-12">
                <h5 className="border-bottom pb-2">Basic Information</h5>
                <div className="row g-3 mt-2">
                  <div className="col-md-6">
                    <label className="form-label">Role Name *</label>
                    <input
                      type="text"
                      value={roleForm.name}
                      onChange={(e) => setRoleForm({ ...roleForm, name: e.target.value })}
                      placeholder="e.g., Regional Supervisor"
                      className="form-control"
                    />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Permission Type</label>
                    <select
                      value={roleForm.permission_type}
                      onChange={(e) => setRoleForm({ ...roleForm, permission_type: e.target.value })}
                      className="form-select"
                    >
                      <option value="hierarchical">Hierarchical</option>
                      <option value="lead_based">Lead Based</option>
                      <option value="hybrid">Hybrid</option>
                    </select>
                  </div>
                  <div className="col-12">
                    <label className="form-label">Description *</label>
                    <textarea
                      value={roleForm.description}
                      onChange={(e) => setRoleForm({ ...roleForm, description: e.target.value })}
                      placeholder="Describe the role's responsibilities..."
                      rows={3}
                      className="form-control"
                    />
                  </div>
                </div>
              </div>

              {/* View Permissions Section */}
              {(roleForm.permission_type === 'hierarchical' || roleForm.permission_type === 'hybrid') && (
                <div className="col-12">
                  <h5 className="border-bottom pb-2">View Permissions</h5>
                  <div className="mt-3">
                    {/* Global or Specific Choice */}
                    <div className="row g-2 mb-4">
                      <div className="col-12">
                        <div className="form-check mb-2">
                          <input
                            type="radio"
                            name="view_access_type"
                            value="GLOBAL"
                            checked={roleForm.view_permissions.global}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              view_permissions: {
                                global: true,
                                hierarchical_selection: {
                                  selected_verticals: [],
                                  selected_projects: [],
                                  selected_centers: [],
                                  selected_courses: [],
                                  selected_batches: []
                                }
                              }
                            })}
                            className="form-check-input"
                            id="view_global"
                          />
                          <label className="form-check-label fw-medium" htmlFor="view_global">
                            🌍 Global View Access
                          </label>
                          <div className="text-muted small">Can view all content across the entire system</div>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-check">
                          <input
                            type="radio"
                            name="view_access_type"
                            value="SPECIFIC"
                            checked={!roleForm.view_permissions.global}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              view_permissions: {
                                global: false,
                                hierarchical_selection: {
                                  selected_verticals: [],
                                  selected_projects: [],
                                  selected_centers: [],
                                  selected_courses: [],
                                  selected_batches: []
                                }
                              }
                            })}
                            className="form-check-input"
                            id="view_specific"
                          />
                          <label className="form-check-label fw-medium" htmlFor="view_specific">
                            🎯 Specific Hierarchical Access
                          </label>
                          <div className="text-muted small">Select specific verticals, then their projects, centers, etc.</div>
                        </div>
                      </div>
                    </div>

                    {/* Hierarchical Selection */}
                    {!roleForm.view_permissions.global && (
                      <div className="card border" style={{ backgroundColor: '#f8f9fa' }}>
                        <div className="card-body">
                          <h6 className="card-title text-dark mb-4 d-flex align-items-center gap-2">
                            <span className="badge bg-secondary">📊</span>
                            Hierarchical View Selection
                          </h6>

                          {/* Step 1: Select Verticals */}
                          <div className="mb-4">
                            <div className="d-flex align-items-center gap-2 mb-3">
                              <span className="badge bg-dark text-white">1</span>
                              <label className="form-label fw-medium mb-0 text-dark">Select Verticals</label>
                            </div>
                            <div className="border rounded p-3 bg-white shadow-sm">
                              {entities.VERTICAL.map(vertical => (
                                <div key={vertical.id} className="form-check mb-2">
                                  <input
                                    type="checkbox"
                                    className="form-check-input"
                                    checked={roleForm.view_permissions.hierarchical_selection.selected_verticals.includes(vertical.id)}
                                    onChange={(e) => {
                                      const current = roleForm.view_permissions.hierarchical_selection.selected_verticals;
                                      const updated = e.target.checked
                                        ? [...current, vertical.id]
                                        : current.filter(id => id !== vertical.id);
                                      updateHierarchicalSelection('verticals', updated);
                                    }}
                                    id={`vertical_${vertical.id}`}
                                  />
                                  <label className="form-check-label fw-medium text-dark" htmlFor={`vertical_${vertical.id}`}>
                                    {vertical.name}
                                  </label>
                                </div>
                              ))}
                              {roleForm.view_permissions.hierarchical_selection.selected_verticals.length > 0 && (
                                <div className="alert alert-light border-success py-2 mt-2 mb-0">
                                  <small className="text-success fw-medium">✅ Selected {roleForm.view_permissions.hierarchical_selection.selected_verticals.length} vertical(s)</small>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Step 2: Select Projects */}
                          {roleForm.view_permissions.hierarchical_selection.selected_verticals.length > 0 && (
                            <div className="mb-4">
                              <div className="d-flex align-items-center gap-2 mb-3">
                                <span className="badge bg-primary text-white">2</span>
                                <label className="form-label fw-medium mb-0 text-dark">Select Projects</label>
                                <small className="text-muted">(from selected verticals)</small>
                              </div>
                              <div className="border rounded p-3 bg-white shadow-sm">
                                {(() => {
                                  const availableProjects = getAvailableProjects(roleForm.view_permissions.hierarchical_selection.selected_verticals);
                                  if (availableProjects.length === 0) {
                                    return <div className="text-muted small">No projects found in selected verticals</div>;
                                  }
                                  return availableProjects.map(project => (
                                    <div key={project.id} className="form-check mb-2">
                                      <input
                                        type="checkbox"
                                        className="form-check-input"
                                        checked={roleForm.view_permissions.hierarchical_selection.selected_projects.includes(project.id)}
                                        onChange={(e) => {
                                          const current = roleForm.view_permissions.hierarchical_selection.selected_projects;
                                          const updated = e.target.checked
                                            ? [...current, project.id]
                                            : current.filter(id => id !== project.id);
                                          updateHierarchicalSelection('projects', updated);
                                        }}
                                        id={`project_${project.id}`}
                                      />
                                      <label className="form-check-label fw-medium text-dark" htmlFor={`project_${project.id}`}>
                                        {project.name}
                                        <small className="text-muted ms-2">
                                          (from {entities.VERTICAL.find(v => v.id === project.parent_id)?.name})
                                        </small>
                                      </label>
                                    </div>
                                  ));
                                })()}
                                {roleForm.view_permissions.hierarchical_selection.selected_projects.length > 0 && (
                                  <div className="alert alert-light border-primary py-2 mt-2 mb-0">
                                    <small className="text-primary fw-medium">✅ Selected {roleForm.view_permissions.hierarchical_selection.selected_projects.length} project(s)</small>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Step 3: Select Centers */}
                          {roleForm.view_permissions.hierarchical_selection.selected_projects.length > 0 && (
                            <div className="mb-4">
                              <div className="d-flex align-items-center gap-2 mb-3">
                                <span className="badge bg-info text-white">3</span>
                                <label className="form-label fw-medium mb-0 text-dark">Select Centers</label>
                                <small className="text-muted">(from selected projects)</small>
                              </div>
                              <div className="border rounded p-3 bg-white shadow-sm">
                                {(() => {
                                  const availableCenters = getAvailableCenters(roleForm.view_permissions.hierarchical_selection.selected_projects);
                                  if (availableCenters.length === 0) {
                                    return <div className="text-muted small">No centers found in selected projects</div>;
                                  }
                                  return availableCenters.map(center => (
                                    <div key={center.id} className="form-check mb-2">
                                      <input
                                        type="checkbox"
                                        className="form-check-input"
                                        checked={roleForm.view_permissions.hierarchical_selection.selected_centers.includes(center.id)}
                                        onChange={(e) => {
                                          const current = roleForm.view_permissions.hierarchical_selection.selected_centers;
                                          const updated = e.target.checked
                                            ? [...current, center.id]
                                            : current.filter(id => id !== center.id);
                                          updateHierarchicalSelection('centers', updated);
                                        }}
                                        id={`center_${center.id}`}
                                      />
                                      <label className="form-check-label fw-medium text-dark" htmlFor={`center_${center.id}`}>
                                        {center.name}
                                        <small className="text-muted ms-2">
                                          (from {entities.PROJECT.find(p => p.id === center.parent_id)?.name})
                                        </small>
                                      </label>
                                    </div>
                                  ));
                                })()}
                                {roleForm.view_permissions.hierarchical_selection.selected_centers.length > 0 && (
                                  <div className="alert alert-light border-info py-2 mt-2 mb-0">
                                    <small className="text-info fw-medium">✅ Selected {roleForm.view_permissions.hierarchical_selection.selected_centers.length} center(s)</small>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Lead-based Permissions */}
              {(roleForm.permission_type === 'lead_based' || roleForm.permission_type === 'hybrid') && (
                <div className="col-12">
                  <h5 className="border-bottom pb-2">Lead Management Permissions</h5>
                  <div className="mt-3">
                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={roleForm.lead_permissions.view_own_leads}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              lead_permissions: {
                                ...roleForm.lead_permissions,
                                view_own_leads: e.target.checked
                              }
                            })}
                            id="view_own_leads"
                          />
                          <label className="form-check-label fw-medium" htmlFor="view_own_leads">
                            View Own Leads
                          </label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={roleForm.lead_permissions.add_leads}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              lead_permissions: {
                                ...roleForm.lead_permissions,
                                add_leads: e.target.checked
                              }
                            })}
                            id="add_leads"
                          />
                          <label className="form-check-label fw-medium" htmlFor="add_leads">
                            Add New Leads
                          </label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={roleForm.lead_permissions.edit_leads}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              lead_permissions: {
                                ...roleForm.lead_permissions,
                                edit_leads: e.target.checked
                              }
                            })}
                            id="edit_leads"
                          />
                          <label className="form-check-label fw-medium" htmlFor="edit_leads">
                            Edit Leads
                          </label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={roleForm.lead_permissions.view_team_leads}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              lead_permissions: {
                                ...roleForm.lead_permissions,
                                view_team_leads: e.target.checked
                              }
                            })}
                            id="view_team_leads"
                          />
                          <label className="form-check-label fw-medium" htmlFor="view_team_leads">
                            View Team Leads
                          </label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={roleForm.lead_permissions.manage_assignments}
                            onChange={(e) => setRoleForm({
                              ...roleForm,
                              lead_permissions: {
                                ...roleForm.lead_permissions,
                                manage_assignments: e.target.checked
                              }
                            })}
                            id="manage_assignments"
                          />
                          <label className="form-check-label fw-medium" htmlFor="manage_assignments">
                            Manage Lead Assignments
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Role Summary */}
              <div className="col-12">
                <div className="alert alert-light">
                  <h6 className="alert-heading">Role Summary</h6>
                  <div className="small">
                    <strong>Type:</strong> {roleForm.permission_type}<br />
                    <strong>Access:</strong> {roleForm.view_permissions.global ? 'Global' : 'Specific'}<br />
                    {roleForm.permission_type !== 'hierarchical' && (
                      <>
                        <strong>Lead Permissions:</strong> {Object.values(roleForm.lead_permissions).filter(Boolean).length} enabled
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onClose}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={!roleForm.name || !roleForm.description}
              className="btn btn-info"
            >
              Create Role
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddRoleModal;